package com.modak;

import com.modak.utils.JSONUtils;
import com.modak.utils.connectionutils.jdbc.JDBCConnectionManager;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.filefilter.TrueFileFilter;

import java.io.File;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.List;

public class UpdateTemplatesInDB {
    static String config;
    static String directory;
    HashMap<String, Object> koshConfig;

    public static void main(String[] args) throws Exception {
        UpdateTemplatesInDB updateTemplatesFromDB = new UpdateTemplatesInDB();
        String classification = "trigger_pipeline";
        String template_version = "1.0";
        config = "C:\\Users\\MT1011\\Downloads\\GetTemplatesFromDatabase\\src\\main\\resources\\kosh_config.json";
        directory = "C:\\Users\\MT1011\\Downloads\\GetTemplatesFromDatabase\\src\\templates_from_db\\dev";
        updateTemplatesFromDB.UpdateTemplates(classification, template_version);
    }

    public void UpdateTemplates(String classification, String template_version) throws Exception {
        this.koshConfig = JSONUtils.jsonToMap(FileUtils.readFileToString(new File(config), Charset.defaultCharset()));
        if (classification.equalsIgnoreCase("trigger_pipeline")) {
            JDBCConnectionManager koshConnectionManager = new JDBCConnectionManager();
            koshConnectionManager.configureHikariDataSourceWithUserPass(koshConfig);
            HikariDataSource hikariDataSource = koshConnectionManager.getHikariDataSource();
            Connection connection = hikariDataSource.getConnection();
            String query = "update nabu.template_group_info set template_group_value = ? where template_group_name= ? " +
                    "and classification = 'trigger_pipeline' and template_version = '" + template_version + "'";

//            String query = "INSERT INTO nabu.template_group_info\n" +
//                    "(template_group_name, description_of_templategroup, template_group_value, template_version, classification, cru_by, cru_ts)\n" +
//                    "VALUES(?, 'Templates for "+classification+"', ?,"+template_version +", '"+classification+"', 'modak', now());\n";
            String templates_directory = directory + File.separator + classification + File.separator + template_version;
            templatesupdateindb(connection, templates_directory, query);
//            templatesinsertindb(connection, templates_directory, query);
        }
    }

    public void templatesupdateindb(Connection con, String directory, String query) throws Exception {
        File dir = new File(directory);
        System.out.println("getting all files in " + directory);
        List<File> files = (List<File>) FileUtils.listFiles(dir, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
        int i = 0;
        for (File file : files) {
            i++;
            System.out.println("file :" + file.getCanonicalPath() + "File Name : " + file.getName());
            String template_name = file.getName().replace(".stg", "");
            System.out.println(file);
            String value = FileUtils.readFileToString(file, Charset.defaultCharset());
            System.out.println(query);
            try {
                PreparedStatement statement = con.prepareStatement(query);


                statement.setString(1, value);
                statement.setString(2, template_name);
                int count = statement.executeUpdate();
                System.out.println("Updated Rows : " + count);
                statement.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        System.out.println("updated " + files.size() + " files");
        con.close();

    }

    public void templatesinsertindb(Connection con, String directory, String query) throws Exception {
        File dir = new File(directory);
        System.out.println("getting all files in " + directory);
        List<File> files = (List<File>) FileUtils.listFiles(dir, TrueFileFilter.INSTANCE, TrueFileFilter.INSTANCE);
        int i = 0;
        for (File file : files) {
            i++;
            System.out.println("file :" + file.getCanonicalPath() + "File Name : " + file.getName());
            String template_name = file.getName().replace(".stg", "");
            String value = FileUtils.readFileToString(file, Charset.defaultCharset());
            System.out.println(query);
            try {
                PreparedStatement statement = con.prepareStatement(query);
                statement.setString(2, value);
                statement.setString(1, template_name);
                int count = statement.executeUpdate();
                System.out.println("Updated Rows : " + count);
                statement.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        System.out.println("updated " + files.size() + " files");
        con.close();

    }

}
