package com.modak;

import com.modak.template.DefaultTemplateFetcher;
import com.modak.template.TemplateFetcher;
import com.modak.template.TemplateServiceFetcher;
import com.modak.utils.JSONUtils;
import com.modak.utils.MapUtils;
import com.modak.utils.connectionutils.jdbc.JDBCConnectionManager;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.MapHandler;
import org.apache.commons.dbutils.handlers.MapListHandler;
import org.apache.commons.io.FileUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.io.File;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GetTemplatesfromDB {
    private static final Logger logger = LogManager.getLogger(GetTemplatesfromDB.class.getSimpleName());
    HashMap<String, Object> koshConfig;
    static String directory;
    static String config;

    public static void main(String[] args) throws Exception {

        GetTemplatesfromDB getTemplatesfromDB = new GetTemplatesfromDB();
        String classification = "ingestion_demo";
        config = "C:\\Users\\MT1011\\Downloads\\GetTemplatesFromDatabase\\src\\main\\resources\\kosh_config.json";

        directory = "C:\\Users\\MT1011\\Downloads\\GetTemplatesFromDatabase\\src\\templates_from_db\\dev";
        getTemplatesfromDB.GetTemplatesfromDB(classification);
    }

    private void GetTemplatesfromDB(String classification) throws Exception {
        this.koshConfig = JSONUtils.jsonToMap(FileUtils.readFileToString(new File(config), Charset.defaultCharset()));
        if (classification.equalsIgnoreCase("ingestion_demo")) {
            JDBCConnectionManager koshConnectionManager = new JDBCConnectionManager();
            koshConnectionManager.configureHikariDataSourceWithUserPass(koshConfig);
            HikariDataSource hikariDataSource = koshConnectionManager.getHikariDataSource();
            Connection connection = hikariDataSource.getConnection();
            String template_version = "1.0";
            String query = "select * from nabu.template_group_info where classification='" + classification + "'  and template_version = '" + template_version + "'";
            String templates_directory = directory + File.separator + classification + File.separator + template_version;
            GetTemplates(connection, templates_directory, query);
        }

    }


    private void GetTemplates(Connection con, String directory, String query) throws Exception {
        QueryRunner queryRunner = new QueryRunner();
        List<Map<String, Object>> mapList = queryRunner.query(con, query, new MapListHandler());
        for (Map<String, Object> map : mapList) {
            String filename = directory + File.separator + map.get("template_group_name").toString() + ".stg";
            FileUtils.writeStringToFile(new File(filename), map.get("template_group_value").toString());
            System.out.println("got template " + filename);
        }
        System.out.println("fetched " + mapList.size() + " templates");
    }


}
