#!/bin/bash

ssh spark-service-account@w3.cdhnode2.modak.com "cd /home/spark-service-account/workarea;./test_almaren.sh $1 $2 $3 $4 $5 $6 $7 $8 $9 ${10}"
